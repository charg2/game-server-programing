#pragma once
#include <cstdint>
#include "DbTask.h"

struct CreateActorTask : public DBTask
{
	CreateActorTask(uint64_t session_id, const char* name);
	virtual ~CreateActorTask();

	char name[50];

	int32_t		user_id;
	//int32_t		y, x;
	//int32_t		hp;
	//int32_t		exp;
	//int8_t		level;

	int8_t		reason;
};

struct UpdatePositionTask : public DBTask
{
	UpdatePositionTask(uint64_t session_id, int32_t user_id, int32_t y, int32_t x);
	virtual ~UpdatePositionTask();

	int32_t		user_id;
	int32_t		y, x;
};

struct LoadActorTask : public DBTask
{
	LoadActorTask(uint64_t session_id, char* name);
	LoadActorTask(const LoadActorTask& other) = delete;
	virtual ~LoadActorTask();

	char name[50];		// id

	int32_t user_id;
	int32_t y, x;
	int32_t level;
	int32_t hp;
	int32_t exp;
};
